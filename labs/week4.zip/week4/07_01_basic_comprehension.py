# write a list comprehension to generate the list below

# [1,2,3,4,5,6,7,8]

list = [i for i in range(1, 9)]